async function fetchStats() {
  const res = await fetch('/api/stats');
  return res.json();
}

async function fetchInsights() {
  const res = await fetch('/api/insights');
  return res.json();
}

function updateStatsDisplay(data) {
  document.getElementById('data-count').textContent = data.count || 0;
  document.getElementById('oda-count').textContent = data.odaNames?.length || 0;
  document.getElementById('last-refresh').textContent = new Date().toLocaleString();
}

function renderInsights(data) {
  const container = document.getElementById('insights');
  container.innerHTML = '';
  if (!data.insights || data.insights.length === 0) {
    container.textContent = 'No insights available';
    return;
  }
  data.insights.forEach(item => {
    const div = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = `${item.oda}`;
    div.appendChild(title);

    const ul = document.createElement('ul');
    item.recommendations.forEach(rec => {
      const li = document.createElement('li');
      li.textContent = rec;
      ul.appendChild(li);
    });
    div.appendChild(ul);
    container.appendChild(div);
  });
}

function makeChart(ctxId, label, labels, data, color) {
  const ctx = document.getElementById(ctxId).getContext('2d');
  return new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label,
        data,
        backgroundColor: labels.map(() => color),
        borderRadius: 8,
        barPercentage: 0.6
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: { mode: 'index', intersect: false }
      },
      scales: {
        x: { ticks: { color: '#9aa6b2' } },
        y: { beginAtZero: true, ticks: { color: '#9aa6b2' } }
      }
    }
  });
}

function renderCharts(stats, odaNames) {
  const temps = [], hums = [], ecs = [], phs = [];
  odaNames.forEach(oda => {
    const odaData = stats[oda] || {};
    const tempKey = Object.keys(odaData).find(k => k.toLowerCase().includes('temp'));
    const nemKey = Object.keys(odaData).find(k => k.toLowerCase().includes('nem') || k.toLowerCase().includes('hum'));
    const ecKey = Object.keys(odaData).find(k => k.toLowerCase().includes('ec'));
    const phKey = Object.keys(odaData).find(k => k.toLowerCase().includes('ph'));

    temps.push(tempKey ? (odaData[tempKey].avg || 0) : 0);
    hums.push(nemKey ? (odaData[nemKey].avg || 0) : 0);
    ecs.push(ecKey ? (odaData[ecKey].avg || 0) : 0);
    phs.push(phKey ? (odaData[phKey].avg || 0) : 0);
  });

  window._charts = window._charts || [];
  window._charts.forEach(c => c.destroy());
  window._charts = [
    makeChart('tempChart', 'Temperature (°C)', odaNames, temps, 'rgba(248,113,113,0.9)'),
    makeChart('humidityChart', 'Humidity (%)', odaNames, hums, 'rgba(96,165,250,0.9)'),
    makeChart('ecChart', 'EC (dS/m)', odaNames, ecs, 'rgba(167,139,250,0.9)'),
    makeChart('phChart', 'pH', odaNames, phs, 'rgba(52,211,153,0.9)')
  ];
}

async function init() {
  const [statsData, insightsData] = await Promise.all([fetchStats(), fetchInsights()]);
  updateStatsDisplay(statsData);
  renderInsights(insightsData);
  renderCharts(statsData.stats, statsData.odaNames || []);
}

init();
