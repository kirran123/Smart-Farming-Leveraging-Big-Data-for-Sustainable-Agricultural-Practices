const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const mongoose = require('mongoose');
const Sensor = require('./models/sensor');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/smart_farming1';
const CSV_PATH = process.env.CSV_PATH || path.join(__dirname, 'data', 'smartfarm.csv');

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
.then(()=> {
  console.log('Connected to MongoDB for import.');
  importCsv();
})
.catch(err=> {
  console.error('MongoDB connection error:', err);
});

function importCsv() {
  const results = [];
  fs.createReadStream(CSV_PATH)
    .pipe(csv())
    .on('data', (data) => {
      // convert numeric strings to numbers where possible
      for (let k of Object.keys(data)) {
        const v = data[k];
        if (v === '') { data[k] = null; continue; }
        const n = Number(v);
        if (!isNaN(n)) data[k] = n;
      }
      results.push(data);
    })
    .on('end', async () => {
      console.log('CSV parsed. Rows:', results.length);
      try {
        await Sensor.insertMany(results);
        console.log('Imported rows into MongoDB collection "sensors".');
      } catch (err) {
        console.error('Import error:', err);
      } finally {
        mongoose.disconnect();
      }
    });
}
