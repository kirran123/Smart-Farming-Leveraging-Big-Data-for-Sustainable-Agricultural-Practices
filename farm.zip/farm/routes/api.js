const express = require('express');
const router = express.Router();
const Sensor = require('../models/sensor');

// GET /api/stats - aggregated simple stats for each ODA sensor
router.get('/stats', async (req, res) => {
  try {
    const docs = await Sensor.find({}).limit(10000).lean();
    if (!docs || docs.length === 0) return res.json({ count: 0, stats: {}, odaNames: [] });

    // determine ODA groups by inspecting keys
    const sample = docs[0];
    const keys = Object.keys(sample);
    const odaNames = [...new Set(keys
      .filter(k => k.match(/ODA\d+/))
      .map(k => k.match(/ODA\d+/)[0]))];

    const stats = {};
    odaNames.forEach(name => {
      stats[name] = { count: 0 };
    });

    docs.forEach(d => {
      odaNames.forEach(oda => {
        const odaKeys = Object.keys(d).filter(k => k.startsWith(oda));
        odaKeys.forEach(k => {
          const field = k.replace(new RegExp('^' + oda + '\\s*'), '');
          const v = d[k];
          if (v === null || v === undefined || typeof v === 'string') {
            return;
          }
          stats[oda].count = stats[oda].count || 0;
          if (!stats[oda][field]) { stats[oda][field] = { sum: 0, min: v, max: v, n: 0 }; }
          const entry = stats[oda][field];
          entry.sum += v;
          entry.n += 1;
          if (v < entry.min) entry.min = v;
          if (v > entry.max) entry.max = v;
        });
      });
    });

    for (const oda of odaNames) {
      for (const field of Object.keys(stats[oda])) {
        if (field === 'count') continue;
        const e = stats[oda][field];
        e.avg = e.n ? (e.sum / e.n) : null;
      }
    }

    res.json({ count: docs.length, stats, odaNames });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/insights - simple heuristic-based recommendations
router.get('/insights', async (req, res) => {
  try {
    const docs = await Sensor.find({}).sort({ _id: -1 }).limit(2000).lean();
    if (!docs || docs.length === 0) return res.json({ insights: [] });

    const odaAgg = {};
    docs.forEach(d => {
      Object.keys(d).forEach(k => {
        const m = k.match(/(ODA\d+)\s+(.*)/);
        if (!m) return;
        const oda = m[1], field = m[2];
        odaAgg[oda] = odaAgg[oda] || {};
        odaAgg[oda][field] = odaAgg[oda][field] || { sum:0, n:0 };
        const v = d[k];
        if (typeof v === 'number') {
          odaAgg[oda][field].sum += v;
          odaAgg[oda][field].n += 1;
        }
      });
    });

    const insights = [];
    for (const oda of Object.keys(odaAgg)) {
      const fields = odaAgg[oda];
      const avgTemp = fields['CLIMATE_Temp'] ? fields['CLIMATE_Temp'].sum / fields['CLIMATE_Temp'].n : null;
      const avgCo2 = fields['CLIMATE_Co2'] ? fields['CLIMATE_Co2'].sum / fields['CLIMATE_Co2'].n : null;
      const avgNem = fields['CLIMATE_Nem'] ? fields['CLIMATE_Nem'].sum / fields['CLIMATE_Nem'].n : null;
      const avgPH = fields['DOSE_PH_PH'] ? fields['DOSE_PH_PH'].sum / fields['DOSE_PH_PH'].n : null;
      const avgEC = fields['DOSE_EC_EC'] ? fields['DOSE_EC_EC'].sum / fields['DOSE_EC_EC'].n : null;

      const recs = [];
      if (avgNem !== null && avgNem < 60) recs.push('Soil/air humidity is low — consider increasing irrigation.');
      if (avgTemp !== null && avgTemp > 30) recs.push('Temperature is high — increase irrigation and provide shade if possible.');
      if (avgEC !== null) {
        if (avgEC < 1.0) recs.push('Electrical Conductivity (EC) is low — nutrients may be low; consider balanced fertilization.');
        if (avgEC > 2.5) recs.push('EC is high — risk of salt stress; consider flushing with clean water and reducing fertilizer.');
      }
      if (avgPH !== null) {
        if (avgPH < 5.5) recs.push('pH is acidic — consider liming or adjust nutrient mix to raise pH.');
        if (avgPH > 6.8) recs.push('pH is alkaline — consider acidifying amendments or adjust fertilizer selection.');
      }
      if (avgCo2 !== null && avgCo2 < 350) recs.push('CO2 levels are low for optimal photosynthesis; in closed environments consider supplemental CO2.');
      if (recs.length === 0) recs.push('Conditions appear generally within nominal ranges. Keep monitoring and follow crop-specific best practices.');

      insights.push({ oda, avgTemp, avgCo2, avgNem, avgPH, avgEC, recommendations: recs });
    }

    res.json({ insights });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
