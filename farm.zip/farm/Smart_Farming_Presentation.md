# Slide 1: Smart Farming Dashboard

Project: Smart Farming Dashboard
Your Name, Institution, Date

---

# Slide 2: Problem Statement

Farmers need data-driven advice for irrigation, fertilization, and yield optimization. Manual monitoring is slow and error-prone.

---

# Slide 3: Objectives

1) Store sensor data
2) Analyze and extract insights
3) Visualize via dashboard
4) Provide actionable recommendations

---

# Slide 4: Technologies Used

Frontend: HTML, CSS, JS (Chart.js)
Backend: Node.js, Express
DB: MongoDB
Tools: npm, VSCode

---

# Slide 5: System Architecture

CSV -> Import Script -> MongoDB -> Express API -> Frontend Dashboard (Charts & Insights)

---

# Slide 6: Dataset

File: smartfarm.csv
Columns include sensor readings (temperature, humidity, EC, pH, CO2) across multiple ODA zones.

---

# Slide 7: Data Import & Storage

import_csv.js reads CSV, converts types, and inserts into MongoDB collection 'sensors'.

---

# Slide 8: Backend APIs

/api/stats -> aggregated averages/min/max per ODA
/api/insights -> heuristic recommendations

---

# Slide 9: Analysis Logic

Heuristics (examples):
- humidity<60% -> irrigate
- EC>2.5 -> flush salts
- pH out of range -> adjust soil

---

# Slide 10: Frontend Dashboard

Displays stats, charts (Temp, Humidity, EC, pH), and recommendations. Responsive and professional UI.

---

# Slide 11: Charts & Visualization

Built with Chart.js. Comparative bar charts per ODA. Interactive tooltips and responsive layout.

---

# Slide 12: CSS & Design Choices

Dark themed professional UI, glassy cards, responsive grid, clear typography (Inter). Separate styles.css

---

# Slide 13: Demo Screenshots

Include screenshots of dashboard: overview, chart view, insights.

---

# Slide 14: Results & Advantages

Automated insights, easier farm decisions, scalable to more sensors and advanced analytics.

---

# Slide 15: Future Work & Conclusion

Real-time IoT integration, ML models for yield prediction, deploy to cloud (MongoDB Atlas). Conclusion: prototype ready for extension.

---

