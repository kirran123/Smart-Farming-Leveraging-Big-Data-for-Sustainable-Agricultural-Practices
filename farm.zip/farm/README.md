# Smart Farming Dashboard (Enhanced)

## Overview
This project ingests a CSV dataset (`data/smartfarm.csv`) and provides:
- A Node.js backend (Express) that stores data in MongoDB
- API endpoints for aggregated stats and heuristic insights
- A responsive frontend dashboard with professional styling (external styles.css)
- Charts generated with Chart.js

## Setup
1. Install Node.js and MongoDB locally.
2. Unzip the project, then copy your `smartfarm.csv` into `data/` (already included).
3. From project directory:
   ```bash
   npm install
   npm run import-csv
   npm start
   ```
4. Open http://localhost:3000 in your browser.

## Notes
- MongoDB connection string: mongodb://localhost:27017/smart_farming (change via MONGO_URI env var)
- The heuristics in `/api/insights` are examples; tune thresholds for specific crops.
